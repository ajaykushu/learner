import { Component, EventEmitter,Output } from '@angular/core';
import { Router } from '@angular/router';
import { TempStorageService } from '../Service/temp-storage.service';



@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent {
  isExpanded = false;
  data = "";
 

  constructor(private _router: Router,private  _service: TempStorageService) {
   
  }
  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }
 
  searchData() {
   
   
  
    this._service.emitChange(this.data);
    this._router.navigate(['/product_details']);
  }
}
