import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { PrductDetailsComponent } from './prduct-details/prduct-details.component';
import { TempStorageService } from './Service/temp-storage.service';
import { FilterComponent } from './filter/filter.component';
import { CompleteDetailsComponent } from './complete-details/complete-details.component';
import { SpecifictionComponent } from './specifiction/specifiction.component';
import { ReviewsRatingCommentsComponent } from './reviews-rating-comments/reviews-rating-comments.component';
import { CommentsComponent } from './comments/comments.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    PrductDetailsComponent,
    FilterComponent,
    CompleteDetailsComponent,
    SpecifictionComponent,
    ReviewsRatingCommentsComponent, 
    CommentsComponent
   
    
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    MDBBootstrapModule,
    AngularFontAwesomeModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'product_details', component: PrductDetailsComponent, pathMatch: 'full' },
      { path: 'product_comp_details', component: CompleteDetailsComponent, pathMatch: 'full' },
     
    ])
  ],
    
  providers: [TempStorageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
