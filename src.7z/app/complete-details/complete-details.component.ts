import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complete-details',
  templateUrl: './complete-details.component.html',
  styleUrls: ['./complete-details.component.css']
})
export class CompleteDetailsComponent implements OnInit {
  Expand_value: any = "spec";
  constructor() { }
  Expand(data) {
    this.Expand_value = data;
  }



  ngOnInit() {
  }

}
