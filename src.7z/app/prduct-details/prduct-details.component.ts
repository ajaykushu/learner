import { Component, OnInit,Input,Pipe } from '@angular/core';
import { TempStorageService } from '../Service/temp-storage.service';



@Component({
  selector: 'app-prduct-details',
  templateUrl: './prduct-details.component.html',
  styleUrls: ['./prduct-details.component.css']
})
export class PrductDetailsComponent implements OnInit {

  close: any=0;
  constructor(private _service: TempStorageService) {
    _service.filterclose$.subscribe(
      val => {
        this.close = val;
      });
  }
  openfiler() {
    this.close = !this.close;
   
    this._service.emitfilter(this.close);
  }

  ngOnInit() {

  }

}
