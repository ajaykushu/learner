import { Component, OnInit,Pipe } from '@angular/core';
import { TempStorageService } from '../Service/temp-storage.service';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  rating = 3;
  price = 5000;
  ram = 2;
  count_of_brand = 10;
  search_string: any;
  close: any = 0;

  constructor(private _service: TempStorageService) {
    _service.changeEmitted$.subscribe(
      text => {
        this.search_string = text;
      });
    _service.filterclose$.subscribe(
      close => {
        this.close = close;
      });
  }
    closefilter()
    {
      this.close = !this.close;
      this._service.emitfilter(this.close);
    }
   

 


  ngOnInit() {
    
  }

}
