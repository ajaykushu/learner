import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-specifiction',
  templateUrl: './specifiction.component.html',
  styleUrls: ['./specifiction.component.css']
})
export class SpecifictionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
