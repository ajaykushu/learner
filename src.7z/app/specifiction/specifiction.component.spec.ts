import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecifictionComponent } from './specifiction.component';

describe('SpecifictionComponent', () => {
  let component: SpecifictionComponent;
  let fixture: ComponentFixture<SpecifictionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecifictionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecifictionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
