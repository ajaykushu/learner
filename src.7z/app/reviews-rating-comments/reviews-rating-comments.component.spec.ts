import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewsRatingCommentsComponent } from './reviews-rating-comments.component';

describe('ReviewsRatingCommentsComponent', () => {
  let component: ReviewsRatingCommentsComponent;
  let fixture: ComponentFixture<ReviewsRatingCommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewsRatingCommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewsRatingCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
