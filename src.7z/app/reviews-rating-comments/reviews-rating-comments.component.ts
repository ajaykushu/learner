import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reviews-rating-comments',
  templateUrl: './reviews-rating-comments.component.html',
  styleUrls: ['./reviews-rating-comments.component.css']
})
export class ReviewsRatingCommentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
