import { TestBed, inject } from '@angular/core/testing';

import { TempStorageService } from './temp-storage.service';

describe('TempStorageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TempStorageService]
    });
  });

  it('should be created', inject([TempStorageService], (service: TempStorageService) => {
    expect(service).toBeTruthy();
  }));
});
