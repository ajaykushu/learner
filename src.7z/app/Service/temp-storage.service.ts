import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TempStorageService {
  
  constructor() { }
  private emitChangeSource = new Subject<any>();
  private emitfilterclose = new Subject<any>();
  // Observable string streams
  changeEmitted$ = this.emitChangeSource.asObservable();
  filterclose$ = this.emitfilterclose.asObservable();
  // Service message commands
  emitChange(change: any) {
    this.emitChangeSource.next(change);
  }
  emitfilter(change: any) {
    this.emitfilterclose.next(change);
  }

}
